def lambda_handler(event, context):
    return {"body": "This is version 1"}
