# Building Serverless Applications with AWS Serverless Application Model (SAM)
